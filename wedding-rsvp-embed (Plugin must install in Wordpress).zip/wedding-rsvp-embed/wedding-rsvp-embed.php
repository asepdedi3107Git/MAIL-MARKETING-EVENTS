<?php
/**
 * Plugin Name: Wedding RSVP Embed
 * Plugin URI: https://digitalinvitee.com
 * Description: Embed halaman RSVP dari Wedding Mail Marketing ke halaman WordPress. Gunakan shortcode <strong>[wedding_rsvp]</strong> di halaman manapun.
 * Version: 1.0.0
 * Author: Digital Invitee
 * Author URI: https://digitalinvitee.com
 * License: GPL v2 or later
 * Text Domain: wedding-rsvp-embed
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// SETTINGS PAGE
// ============================================
class Wedding_RSVP_Embed_Settings
{

    public function __construct()
    {
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'settings_link']);
    }

    public function enqueue_admin_scripts($hook)
    {
        if ($hook !== 'settings_page_wedding-rsvp-embed') {
            return;
        }
        wp_enqueue_media();
        // Load native wp-color-picker
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }

    public function settings_link($links)
    {
        $link = '<a href="options-general.php?page=wedding-rsvp-embed">Settings</a>';
        array_unshift($links, $link);
        return $links;
    }

    public function add_settings_page()
    {
        add_options_page(
            'Wedding RSVP Embed',
            'Wedding RSVP',
            'manage_options',
            'wedding-rsvp-embed',
        [$this, 'render_settings_page']
        );
    }

    public function register_settings()
    {
        // 1. KONEKSI UTAMA
        register_setting('wedding_rsvp_embed_options', 'wre_mail_marketing_url', [
            'type' => 'string',
            'sanitize_callback' => function ($val) {
            return rtrim(esc_url_raw($val), '/');
        },
            'default' => 'https://emailmarketing.digitalinvitee.com',
        ]);
        register_setting('wedding_rsvp_embed_options', 'wre_mail_marketing_client_id', ['type' => 'integer', 'sanitize_callback' => 'intval', 'default' => 0]);

        add_settings_section('wre_main_section', '1. Pengaturan Koneksi API', function () {
            echo '<p>Konfigurasi koneksi ke server Wedding Mail Marketing Anda.</p>';
        }, 'wedding-rsvp-embed');
        add_settings_field('wre_mail_marketing_url', 'Mail Marketing URL', [$this, 'render_url_field'], 'wedding-rsvp-embed', 'wre_main_section');
        add_settings_field('wre_mail_marketing_client_id', 'Mail Marketing Client ID', [$this, 'render_client_id_field'], 'wedding-rsvp-embed', 'wre_main_section');

        // 2. DESAIN & VISUAL LOGIN
        $design_fields = ['wre_bg_image', 'wre_bg_size', 'wre_bg_overlay', 'wre_bg_overlay_opacity', 'wre_font_family', 'wre_title_size', 'wre_desc_size', 'wre_title_color', 'wre_desc_color', 'wre_btn_color', 'wre_btn_text_color'];
        foreach ($design_fields as $field)
            register_setting('wedding_rsvp_embed_options', $field, ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);

        add_settings_section('wre_design_section', '2. Desain Visual Layar Login', function () {
            echo '<p>Kustomisasi tampilan layar proteksi password/email.</p>';
        }, 'wedding-rsvp-embed');
        add_settings_field('wre_bg_image', 'Gambar Background', [$this, 'render_bg_image_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_bg_size', 'Ukuran Background', [$this, 'render_bg_size_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_bg_overlay', 'Warna Overlay Gelap', [$this, 'render_bg_overlay_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_font_family', 'Jenis Font (Google Font)', [$this, 'render_font_family_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_title_size', 'Ukuran Font Judul', [$this, 'render_title_size_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_desc_size', 'Ukuran Font Deskripsi', [$this, 'render_desc_size_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_title_color', 'Warna Judul', [$this, 'render_title_color_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_desc_color', 'Warna Deskripsi', [$this, 'render_desc_color_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_btn_color', 'Warna Tombol', [$this, 'render_btn_color_field'], 'wedding-rsvp-embed', 'wre_design_section');
        add_settings_field('wre_btn_text_color', 'Warna Teks Tombol', [$this, 'render_btn_text_color_field'], 'wedding-rsvp-embed', 'wre_design_section');

        // 3. TEKS & COPYWRITING LOGIN
        $text_fields = ['wre_form_title', 'wre_form_desc', 'wre_placeholder', 'wre_btn_text', 'wre_btn_loading', 'wre_msg_success', 'wre_msg_error'];
        foreach ($text_fields as $field)
            register_setting('wedding_rsvp_embed_options', $field, ['type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field']);

        add_settings_section('wre_text_section', '3. Teks & Copywriting Layar Login', function () {
            echo '<p>Ubah semua kata-kata yang muncul di layar form login tamu.</p>';
        }, 'wedding-rsvp-embed');
        add_settings_field('wre_form_title', 'Judul Form', [$this, 'render_form_title_field'], 'wedding-rsvp-embed', 'wre_text_section');
        add_settings_field('wre_form_desc', 'Deskripsi Form', [$this, 'render_form_desc_field'], 'wedding-rsvp-embed', 'wre_text_section');
        add_settings_field('wre_placeholder', 'Placeholder Kotak Email', [$this, 'render_placeholder_field'], 'wedding-rsvp-embed', 'wre_text_section');
        add_settings_field('wre_btn_text', 'Teks Tombol Normal', [$this, 'render_btn_text_field'], 'wedding-rsvp-embed', 'wre_text_section');
        add_settings_field('wre_btn_loading', 'Teks Tombol Proses', [$this, 'render_btn_loading_field'], 'wedding-rsvp-embed', 'wre_text_section');
        add_settings_field('wre_msg_success', 'Pesan Sukses', [$this, 'render_msg_success_field'], 'wedding-rsvp-embed', 'wre_text_section');
        add_settings_field('wre_msg_error', 'Pesan Error Default', [$this, 'render_msg_error_field'], 'wedding-rsvp-embed', 'wre_text_section');
    }

    public function render_url_field()
    {
        $val = get_option('wre_mail_marketing_url', 'https://emailmarketing.digitalinvitee.com');
        echo '<input type="url" name="wre_mail_marketing_url" value="' . esc_attr($val) . '" class="regular-text ltr" placeholder="https://emailmarketing.digitalinvitee.com" />';
    }

    public function render_client_id_field()
    {
        $val = get_option('wre_mail_marketing_client_id', 0);
        echo '<input type="number" name="wre_mail_marketing_client_id" value="' . esc_attr($val) . '" class="regular-text" />';
        echo '<p class="description">Dibutuhkan untuk sinkronisasi tamu dan pelindung RSVP.</p>';
    }

    public function render_bg_image_field()
    {
        $val = get_option('wre_bg_image', '');
        echo '<input type="hidden" name="wre_bg_image" id="wre_bg_image" value="' . esc_attr($val) . '" />';
        echo '<div style="margin-bottom:10px;"><img id="wre-bg-preview" src="' . esc_url($val) . '" style="max-width:300px; max-height:200px; display:' . ($val ? 'block' : 'none') . '; border: 3px solid #ccc; border-radius: 8px;" /></div>';
        echo '<button type="button" class="button button-secondary" id="wre-upload-bg-button">🖼️ Pilih / Upload Gambar</button> ';
        echo '<button type="button" class="button button-link-delete" id="wre-remove-bg-button">Hapus Gambar</button>';
        echo '<p class="description">Gambar akan menyesuaikan layar secara penuh (cover background).</p>';
    }

    public function render_bg_overlay_field()
    {
        $color = get_option('wre_bg_overlay', '#000000');
        if (strpos($color, 'rgba') !== false)
            $color = '#000000'; // reset legacy rgba format to hex
        $opacity = get_option('wre_bg_overlay_opacity', '60');

        echo '<div style="display:flex; align-items:flex-end; gap: 20px;">';
        echo '<div><label style="display:block;margin-bottom:5px;font-weight:600;">Warna Latar:</label>';
        echo '<input type="text" name="wre_bg_overlay" value="' . esc_attr($color) . '" class="wre-color-picker" /></div>';
        echo '<div><label style="display:block;margin-bottom:5px;font-weight:600;">Tingkat Transparansi: <span id="wre_opacity_val">' . esc_html($opacity) . '%</span></label>';
        echo '<input type="range" name="wre_bg_overlay_opacity" id="wre_bg_overlay_opacity" min="0" max="100" value="' . esc_attr($opacity) . '" style="width: 250px; vertical-align: middle;" oninput="document.getElementById(\'wre_opacity_val\').innerText = this.value + \'%\'" /></div>';
        echo '</div>';
        echo '<p class="description" style="margin-top:10px;">Atur warna gelap dan geser bar transparansinya agar formulir terbaca dengan jelas.</p>';
    }

    public function render_bg_size_field()
    {
        $val = get_option('wre_bg_size', 'cover');
        echo '<select name="wre_bg_size">
            <option value="cover" ' . selected($val, 'cover', false) . '>Cover (Memenuhi Layar)</option>
            <option value="contain" ' . selected($val, 'contain', false) . '>Contain (Sesuai Ukuran Gambar)</option>
            <option value="auto" ' . selected($val, 'auto', false) . '>Auto (Ukuran Asli)</option>
        </select>';
    }

    public function render_font_family_field()
    {
        $val = get_option('wre_font_family', 'Cormorant Garamond');
        echo '<input type="text" name="wre_font_family" value="' . esc_attr($val) . '" class="regular-text" />';
        echo '<p class="description">Nama font dari Google Fonts (misal: <code>Cormorant Garamond</code>, <code>Playfair Display</code>, <code>Montserrat</code>).</p>';
    }

    public function render_title_size_field()
    {
        $val = get_option('wre_title_size', '32px');
        echo '<input type="text" name="wre_title_size" value="' . esc_attr($val) . '" class="small-text" />';
    }

    public function render_desc_size_field()
    {
        $val = get_option('wre_desc_size', '15px');
        echo '<input type="text" name="wre_desc_size" value="' . esc_attr($val) . '" class="small-text" />';
    }

    public function render_title_color_field()
    {
        $val = get_option('wre_title_color', '#0f172a');
        echo '<input type="text" name="wre_title_color" value="' . esc_attr($val) . '" class="wre-color-picker" />';
    }

    public function render_desc_color_field()
    {
        $val = get_option('wre_desc_color', '#475569');
        echo '<input type="text" name="wre_desc_color" value="' . esc_attr($val) . '" class="wre-color-picker" />';
    }

    public function render_btn_color_field()
    {
        $val = get_option('wre_btn_color', '#0f172a');
        echo '<input type="text" name="wre_btn_color" value="' . esc_attr($val) . '" class="wre-color-picker" />';
    }

    public function render_btn_text_color_field()
    {
        $val = get_option('wre_btn_text_color', '#ffffff');
        echo '<input type="text" name="wre_btn_text_color" value="' . esc_attr($val) . '" class="wre-color-picker" />';
    }

    public function render_form_title_field()
    {
        $val = get_option('wre_form_title', 'Undangan Pribadi');
        echo '<input type="text" name="wre_form_title" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function render_form_desc_field()
    {
        $val = get_option('wre_form_desc', 'Silakan masukkan alamat email yang telah didaftarkan untuk membuka undangan ini.');
        echo '<textarea name="wre_form_desc" rows="3" class="large-text">' . esc_textarea($val) . '</textarea>';
    }

    public function render_placeholder_field()
    {
        $val = get_option('wre_placeholder', 'contoh@email.com');
        echo '<input type="text" name="wre_placeholder" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function render_btn_text_field()
    {
        $val = get_option('wre_btn_text', 'Buka Undangan');
        echo '<input type="text" name="wre_btn_text" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function render_btn_loading_field()
    {
        $val = get_option('wre_btn_loading', 'Memeriksa...');
        echo '<input type="text" name="wre_btn_loading" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function render_msg_success_field()
    {
        $val = get_option('wre_msg_success', 'Berhasil! Mengalihkan...');
        echo '<input type="text" name="wre_msg_success" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function render_msg_error_field()
    {
        $val = get_option('wre_msg_error', 'Tidak dapat terhubung ke server. Silakan coba lagi.');
        echo '<input type="text" name="wre_msg_error" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function render_settings_page()
    {
        if (!current_user_can('manage_options'))
            return;
?>
        <div class="wrap">
            <h1>💌 Pengaturan RSVP & Form Proteksi Email</h1>
            <form method="post" action="options.php">
                <?php
        settings_fields('wedding_rsvp_embed_options');
        do_settings_sections('wedding-rsvp-embed');
        submit_button('Simpan Pengaturan');
?>
            </form>

            <script>
                jQuery(document).ready(function($){
                    // Initialize WP Color Picker with Alpha channel support
                    $('.wre-color-picker').wpColorPicker();

                    var mediaUploader;
                    $('#wre-upload-bg-button').click(function(e) {
                        e.preventDefault();
                        if (mediaUploader) { mediaUploader.open(); return; }
                        mediaUploader = wp.media.frames.file_frame = wp.media({
                            title: 'Pilih Gambar Background Form',
                            button: { text: 'Gunakan Gambar Ini' },
                            multiple: false
                        });
                        mediaUploader.on('select', function() {
                            var attachment = mediaUploader.state().get('selection').first().toJSON();
                            $('#wre_bg_image').val(attachment.url);
                            $('#wre-bg-preview').attr('src', attachment.url).show();
                        });
                        mediaUploader.open();
                    });
                    $('#wre-remove-bg-button').click(function(e) {
                        e.preventDefault();
                        $('#wre_bg_image').val('');
                        $('#wre-bg-preview').hide().attr('src','');
                    });
                });
            </script>

            <hr />
            <h2>Cara Pakai</h2>
            <table class="widefat" style="max-width:700px;">
                <tbody>
                    <tr>
                        <td><strong>1.</strong></td>
                        <td>Buat halaman baru di WordPress (misal: <code>/rsvp/</code>)</td>
                    </tr>
                    <tr>
                        <td><strong>2.</strong></td>
                        <td>Tambahkan shortcode: <code>[wedding_rsvp]</code></td>
                    </tr>
                    <tr>
                        <td><strong>3.</strong></td>
                        <td>Link yang dikirim ke tamu:<br>
                            <code><?php echo home_url('/rsvp/?token=TOKEN_TAMU'); ?></code>
                        </td>
                    </tr>
                </tbody>
            </table>

            <h3 style="margin-top:20px;">Opsi Shortcode Iframe <code>[wedding_rsvp]</code></h3>
            <table class="widefat" style="max-width:700px;">
                <thead>
                    <tr><th>Parameter</th><th>Default</th><th>Keterangan</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>height</code></td><td><?php echo esc_html(get_option('wre_iframe_height', '900px')); ?></td><td>Tinggi iframe</td></tr>
                    <tr><td><code>loading</code></td><td>lazy</td><td>lazy / eager</td></tr>
                </tbody>
            </table>
            <p>Contoh: <code>[wedding_rsvp height="1000px"]</code></p>

            <hr />
            <h3 style="margin-top:20px;">Alternatif: Tombol Elementor Asli & Menu Link</h3>
            <p>Jika Anda ingin menggunakan widget <strong>Button bawaan Elementor</strong>, plugin tambahan tombol Anda, atau bahkan menyisipkannya di <strong>Menu Header WordPress</strong>, caranya sangat praktis:</p>
            <p>Di bagian kolom URL / Tautan / Link, cukup ketik persis seperti ini:</p>
            <code>#rsvp_link#</code>
            <p><strong>Cara Kerjanya:</strong><br>
            Sistem kami akan secara otomatis memindai seluruh halaman web Anda. Setiap kali ia menemukan link bertuliskan <code>#rsvp_link#</code>, ia akan otomatis menyulapnya menjadi link RSVP asli yang memuat token tamu saat ini.</p>
        </div>
        <?php
    }
}

new Wedding_RSVP_Embed_Settings();

// ============================================
// CORE LOGIC: PROTEKSI PASSWORD & HIDE RSVP
// ============================================

add_action('wp', 'wre_check_website_password_protection', 0);
add_action('template_redirect', 'wre_check_website_password_protection', 0);

// Tambahkan shortcode manual jika hooks gagal dipanggil oleh tema
add_shortcode('wre_gatekeeper', 'wre_manual_gatekeeper_shortcode');

function wre_manual_gatekeeper_shortcode()
{
    wre_check_website_password_protection(true);
    return ''; // Jika lolos, kembalikan kosong
}

function wre_check_website_password_protection($is_shortcode = false)
{
    // Jangan proses jika di admin area, feed, atau REST API
    if (is_admin() || wp_is_json_request() || wp_doing_ajax() || is_feed()) {
        return;
    }

    // Bypass Elementor Editor & Preview agar tidak terkunci
    if (isset($_GET['elementor-preview']) || isset($_GET['action']) && $_GET['action'] === 'elementor') {
        return;
    }

    $client_id = get_option('wre_mail_marketing_client_id', 0);
    $base_url = get_option('wre_mail_marketing_url', 'https://emailmarketing.digitalinvitee.com');
    $base_url = rtrim($base_url, '/');

    if (!$client_id || empty($base_url)) {
        return; // Belum dikonfigurasi
    }

    // 1. Cek Token dari URL terlebih dahulu
    $token_from_url = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';

    // 2. Set Cookie jika ada token di URL agar tamu tetap login saat pindah antar halaman
    if (!empty($token_from_url)) {
        setcookie('wre_guest_token', $token_from_url, time() + (86400 * 30), COOKIEPATH, COOKIE_DOMAIN);
        $_COOKIE['wre_guest_token'] = $token_from_url; // Set di superglobal untuk pengecekan berikutnya
    }

    $current_token = $token_from_url ?: ($_COOKIE['wre_guest_token'] ?? '');

    // 3. Panggil API untuk cek status proteksi
    $api_url = $base_url . '/api.php?action=get_site_password_status&client_id=' . $client_id;
    $response = wp_remote_get($api_url, [
        'timeout' => 5,
        'sslverify' => false
    ]);

    $is_protected = false;

    if (!is_wp_error($response)) {
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if (isset($data['status']) && $data['status'] === true) {
            $is_protected = !empty($data['site_password_enabled']);
        }
    }

    // Jika diproteksi DAN tidak ada token, tampilkan form login
    if ($is_protected && empty($current_token)) {
        wre_render_login_page();
        exit;
    }

    // Jika TIDAK diproteksi DAN tidak ada token, masukkan CSS & JS untuk menyembunyikan tombol RSVP
    if (!$is_protected && empty($current_token)) {
        add_action('wp_head', 'wre_hide_rsvp_elements_css');
        add_action('wp_footer', 'wre_hide_rsvp_elements_js', 99);
    }
}

// ============================================
// TAMPILAN HALAMAN LOGIN EMAIL
// ============================================
function wre_render_login_page()
{
    $bg_image = get_option('wre_bg_image', '');
    $bg_size = get_option('wre_bg_size', 'cover');

    // Convert hex + opacity to rgba
    $overlay_hex = get_option('wre_bg_overlay', '#000000');
    if (strpos($overlay_hex, 'rgba') !== false) {
        $bg_overlay = $overlay_hex;
    }
    else {
        $overlay_opacity = get_option('wre_bg_overlay_opacity', '60');
        $hex = str_replace('#', '', $overlay_hex);
        if (strlen($hex) == 6) {
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        }
        elseif (strlen($hex) == 3) {
            $r = hexdec(str_repeat(substr($hex, 0, 1), 2));
            $g = hexdec(str_repeat(substr($hex, 1, 1), 2));
            $b = hexdec(str_repeat(substr($hex, 2, 1), 2));
        }
        else {
            $r = 0;
            $g = 0;
            $b = 0;
        }
        $bg_overlay = "rgba($r, $g, $b, " . ($overlay_opacity / 100) . ")";
    }

    $font_family = get_option('wre_font_family', 'Cormorant Garamond');
    if (empty($font_family))
        $font_family = 'Cormorant Garamond';

    $title_size = get_option('wre_title_size', '32px');
    $desc_size = get_option('wre_desc_size', '15px');
    $title_color = get_option('wre_title_color', '#0f172a');
    $desc_color = get_option('wre_desc_color', '#475569');

    $btn_color = get_option('wre_btn_color', '#0f172a');
    $btn_text_color = get_option('wre_btn_text_color', '#ffffff');

    $form_title = get_option('wre_form_title', 'Undangan Pribadi');
    $form_desc = get_option('wre_form_desc', 'Silakan masukkan alamat email yang telah didaftarkan untuk membuka undangan ini.');
    $placeholder = get_option('wre_placeholder', 'contoh@email.com');
    $btn_text = get_option('wre_btn_text', 'Buka Undangan');
    $btn_loading = get_option('wre_btn_loading', 'Memeriksa...');
    $msg_success = get_option('wre_msg_success', 'Berhasil! Mengalihkan...');
    $msg_error = get_option('wre_msg_error', 'Tidak dapat terhubung ke server. Silakan coba lagi.');

    // Menggunakan template dasar HTML agar bebas dari tema WordPress yang berantakan
?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo esc_html($form_title); ?> - <?php bloginfo('name'); ?></title>
        <?php if ($font_family !== 'Inter'): ?>
        <link href="https://fonts.googleapis.com/css2?family=<?php echo urlencode($font_family); ?>:wght@400;500;600;700&display=swap" rel="stylesheet">
        <?php
    else: ?>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
        <?php
    endif; ?>
        
        <style>
            body { 
                margin: 0; 
                padding: 0; 
                font-family: '<?php echo esc_attr($font_family); ?>', sans-serif; 
                background-color: #f8fafc; 
                <?php if ($bg_image): ?>
                background-image: linear-gradient(<?php echo esc_attr($bg_overlay); ?>, <?php echo esc_attr($bg_overlay); ?>), url('<?php echo esc_url($bg_image); ?>');
                background-size: <?php echo esc_attr($bg_size); ?>;
                background-position: center;
                background-attachment: fixed;
                <?php if ($bg_size == 'contain' || $bg_size == 'auto')
            echo "background-repeat: no-repeat; background-color: " . esc_attr($bg_overlay) . ";"; ?>
                <?php
    endif; ?>
                display: flex; 
                align-items: center; 
                justify-content: center; 
                min-height: 100vh;
                color: #334155;
            }
            .login-container {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(12px);
                -webkit-backdrop-filter: blur(12px);
                padding: 40px;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                width: 90%;
                max-width: 420px;
                text-align: center;
                box-sizing: border-box;
                border: 1px solid rgba(255,255,255,0.4);
            }
            .login-icon {
                font-size: 48px;
                margin-bottom: 20px;
            }
            h1 {
                font-size: <?php echo esc_attr($title_size); ?>;
                font-weight: 700;
                margin: 0 0 10px 0;
                color: <?php echo esc_attr($title_color); ?>;
                line-height: 1.2;
            }
            p.form-desc {
                font-size: <?php echo esc_attr($desc_size); ?>;
                color: <?php echo esc_attr($desc_color); ?>;
                margin: 0 0 30px 0;
                line-height: 1.6;
            }
            .input-group {
                margin-bottom: 25px;
                text-align: left;
            }
            input[type="email"] {
                width: 100%;
                padding: 14px 16px;
                border: 1px solid #cbd5e1;
                border-radius: 10px;
                font-size: 15px;
                font-family: '<?php echo esc_attr($font_family); ?>', sans-serif;
                box-sizing: border-box;
                transition: all 0.2s;
                background: rgba(255,255,255,0.9);
            }
            input[type="email"]:focus {
                outline: none;
                border-color: #3b82f6;
                box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15);
                background: #fff;
            }
            button {
                width: 100%;
                padding: 15px;
                background-color: <?php echo esc_attr($btn_color); ?>;
                color: <?php echo esc_attr($btn_text_color); ?>;
                border: none;
                border-radius: 10px;
                font-size: 16px;
                font-weight: 600;
                font-family: '<?php echo esc_attr($font_family); ?>', sans-serif;
                cursor: pointer;
                transition: all 0.2s;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            }
            button:hover {
                filter: brightness(0.9);
                transform: translateY(-1px);
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            }
            button:active {
                transform: translateY(1px);
            }
            button:disabled {
                background-color: #94a3b8;
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }
            .error-message {
                color: #ef4444;
                font-size: 14px;
                background: #fef2f2;
                border: 1px solid #fecaca;
                padding: 12px;
                border-radius: 8px;
                margin-bottom: 20px;
                display: none;
                font-weight: 500;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="login-icon">💌</div>
            <h1><?php echo esc_html($form_title); ?></h1>
            <p class="form-desc"><?php echo nl2br(esc_html($form_desc)); ?></p>
            
            <div class="error-message" id="wre-error"></div>

            <form id="wre-login-form">
                <div class="input-group">
                    <input type="email" id="guest_email" name="guest_email" placeholder="<?php echo esc_attr($placeholder); ?>" required>
                </div>
                <button type="submit" id="wre-submit-btn"><?php echo esc_html($btn_text); ?></button>
            </form>
        </div>

        <script>
            var WRE_CONFIG = {
                btnText: "<?php echo esc_js($btn_text); ?>",
                btnLoading: "<?php echo esc_js($btn_loading); ?>",
                msgSuccess: "<?php echo esc_js($msg_success); ?>",
                msgErrorGeneric: "<?php echo esc_js($msg_error); ?>"
            };

            document.getElementById('wre-login-form').addEventListener('submit', function(e) {
                e.preventDefault();
                var btn = document.getElementById('wre-submit-btn');
                var errorDiv = document.getElementById('wre-error');
                var email = document.getElementById('guest_email').value;
                
                btn.disabled = true;
                btn.innerText = WRE_CONFIG.btnLoading;
                errorDiv.style.display = 'none';

                var formData = new FormData();
                formData.append('action', 'wre_login_guest');
                formData.append('email', email);

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        btn.innerText = WRE_CONFIG.msgSuccess;
                        btn.style.filter = 'brightness(1.5)';
                        window.location.reload();
                    } else {
                        btn.disabled = false;
                        btn.innerText = WRE_CONFIG.btnText;
                        errorDiv.innerText = data.data.message || WRE_CONFIG.msgErrorGeneric;
                        errorDiv.style.display = 'block';
                    }
                })
                .catch(error => {
                    btn.disabled = false;
                    btn.innerText = WRE_CONFIG.btnText;
                    errorDiv.innerText = WRE_CONFIG.msgErrorGeneric;
                    errorDiv.style.display = 'block';
                });
            });
        </script>
    </body>
    </html>
    <?php
}

// ============================================
// AJAX HANDLER UNTUK PROSES LOGIN EMAIL
// ============================================
add_action('wp_ajax_wre_login_guest', 'wre_handle_guest_login');
add_action('wp_ajax_nopriv_wre_login_guest', 'wre_handle_guest_login');

function wre_handle_guest_login()
{
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $client_id = get_option('wre_mail_marketing_client_id', 0);
    $base_url = get_option('wre_mail_marketing_url', 'https://emailmarketing.digitalinvitee.com');
    $base_url = rtrim($base_url, '/');

    if (empty($email) || !$client_id || empty($base_url)) {
        wp_send_json_error(['message' => 'Data tidak lengkap atau konfigurasi plugin belum benar. (Client ID/Email Kosong)']);
    }

    $api_url = $base_url . '/api.php?action=check_guest_email';

    $response = wp_remote_post($api_url, [
        'timeout' => 10,
        'sslverify' => false,
        'body' => [
            'client_id' => $client_id,
            'email' => $email
        ]
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'Gagal menghubungi server database undangan.']);
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['status']) && $data['status'] === true && !empty($data['token'])) {
        // Berhasil! Set cookie dan kirim response sukses
        setcookie('wre_guest_token', sanitize_text_field($data['token']), time() + (86400 * 30), COOKIEPATH, COOKIE_DOMAIN);
        wp_send_json_success(['message' => 'Login berhasil']);
    }
    else {
        $error_msg = isset($data['message']) ? sanitize_text_field($data['message']) : 'Email tidak ditemukan dalam daftar tamu.';
        wp_send_json_error(['message' => $error_msg]);
    }
}

// ============================================
// FUNGSI UNTUK MENYEMBUNYIKAN RSVP JIKA PUBLIK
// ============================================

// Menambahkan CSS untuk menyembunyikan tag a dengan href="#rsvp_link#"
function wre_hide_rsvp_elements_css()
{
    echo '<style>
        /* Sembunyikan semua elemen (menu, tombol) yang memiliki link ke #rsvp_link# */
        a[href="#rsvp_link#"],
        a[href="%23rsvp_link%23"],
        .wre-hide-rsvp { 
            display: none !important; 
        }
    </style>';
}

// Menambahkan Javascript untuk membersihkan container (seperti kolom button di Elementor) jika kosong
function wre_hide_rsvp_elements_js()
{
?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Cari semua link rsvp yang targetnya diubah kembali ke '#' (lihat fungsi get_wre_current_rsvp_url)
        var hiddenLinks = document.querySelectorAll('a[href="#rsvp_link#"], a[href="#"]');
        
        hiddenLinks.forEach(function(link) {
            // Cek apakah ini tombol elementor
            if (link.closest('.elementor-widget-button')) {
                var widgetRow = link.closest('.elementor-widget-button');
                if(widgetRow) widgetRow.style.display = 'none';
            }
            // Cek apakah ini di menu navigasi
            if (link.closest('li.menu-item')) {
                var menuItem = link.closest('li.menu-item');
                if(menuItem) menuItem.style.display = 'none';
            }
        });
    });
    </script>
    <?php
}

// ============================================
// FUNGSI HELPER: MENDAPATKAN URL RSVP SAAT INI
// ============================================
function get_wre_current_rsvp_url()

{
    $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : ($_COOKIE['wre_guest_token'] ?? '');

    $base_url = get_option('wre_mail_marketing_url', 'https://emailmarketing.digitalinvitee.com');
    $base_url = rtrim($base_url, '/');

    // Jika tidak ada token (baik di URL maupun Cookie)
    if (empty($token)) {
        // Cek apakah proteksi password aktif?
        $client_id = get_option('wre_mail_marketing_client_id', 0);
        $is_protected = false;

        if ($client_id) {
            $api_url = $base_url . '/api.php?action=get_site_password_status&client_id=' . $client_id;
            $response = wp_remote_get($api_url, ['timeout' => 5]);
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                if (isset($data['status']) && $data['status'] === true && !empty($data['site_password_enabled'])) {
                    $is_protected = true;
                }
            }
        }

        // Jika TIDAK diproteksi dan TIDAK ada token, matikan klik link RSVP (return #)
        // Karena elemennya sudah disembunyikan oleh CSS/JS, ini lapisan ganda
        if (!$is_protected) {
            return '#';
        }

        // Jika diproteksi, biarkan kembali ke base URL atau halaman ini agar login form muncul
        return esc_url($base_url);
    }

    // Jika ada token, generate link RSVP yang valid
    $base_url = str_replace(['http://https://', 'https://https://', 'http://http://'], 'https://', $base_url);
    return esc_url($base_url . '/rsvp.php?token=' . urlencode($token));
}

// ============================================
// SHORTCODE LAMA (SUDAH DEPRECATED TAPI DIPERTAHANKAN CEGAH ERROR SEBELUMNYA)
// ============================================
function wedding_rsvp_shortcode($atts)
{
    $atts = shortcode_atts([
        'loading' => 'lazy',
    ], $atts, 'wedding_rsvp');

    // Ambil token dari URL
    $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';

    if (empty($token)) {
        return '<div style="text-align:center;padding:60px 20px;color:#94a3b8;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">
            <div style="font-size:48px;margin-bottom:16px;">💌</div>
            <h3 style="font-size:20px;color:#1e293b;margin-bottom:8px;">Undangan Tidak Ditemukan</h3>
            <p style="font-size:14px;">Link undangan Anda tidak valid. Silakan periksa kembali link yang dikirim melalui email atau WhatsApp.</p>
        </div>';
    }

    // Build URL ke halaman RSVP
    $base_url = get_option('wre_mail_marketing_url', 'https://emailmarketing.digitalinvitee.com');
    $rsvp_url = esc_url($base_url . '/rsvp.php?token=' . urlencode($token) . '&embed=1');
    $loading = esc_attr($atts['loading']);

    return '<div class="wre-rsvp-container" style="width:100%;text-align:center;padding:50px 0;background:#f8fafc;border-radius:10px;">
        <h3 style="margin-bottom:20px;font-family:sans-serif;">Tamu Silakan Melengkapi Data RSVP</h3>
        <a href="' . $rsvp_url . '" target="_blank" style="display:inline-block;padding:12px 24px;background:#0f172a;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold;">Buka Form RSVP</a>
    </div>';
}
add_shortcode('wedding_rsvp', 'wedding_rsvp_shortcode');

// ============================================
// FILTER: REPLACE #rsvp_link# DI ELEMENTOR & MENU
// ============================================

// 1. Filter untuk Menu Navigasi WordPress
add_filter('nav_menu_link_attributes', 'wre_replace_menu_rsvp_link', 10, 3);
function wre_replace_menu_rsvp_link($atts, $item, $args)
{
    if (isset($atts['href']) && $atts['href'] === '#rsvp_link#') {
        $atts['href'] = get_wre_current_rsvp_url();
    }
    return $atts;
}

// 2. Filter untuk Elementor Output Layer (Dan seluruh the_content)
add_filter('the_content', 'wre_replace_content_rsvp_link', 99);
function wre_replace_content_rsvp_link($content)
{
    // Cari semua href="#rsvp_link#" atau href="%23rsvp_link%23" dan ganti dengan URL asli
    $real_url = get_wre_current_rsvp_url();

    $content = str_replace('href="#rsvp_link#"', 'href="' . $real_url . '"', $content);
    $content = str_replace('href="%23rsvp_link%23"', 'href="' . $real_url . '"', $content);
    $content = str_replace("href='#rsvp_link#'", "href='" . $real_url . "'", $content);

    return $content;
}
